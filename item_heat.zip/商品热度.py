import pandas as pd

# 1. 读取数据
df = pd.read_csv('Useful_data.csv', usecols=['item_id', 'user_id'])

# 2. 按商品聚合：独立用户数和总交互次数
item_heat = df.groupby('item_id')['user_id'].agg(
    unique_users='nunique',        # 交互过的独立用户数
    total_interactions='count'     # 总交互次数
).reset_index()

# 3. 保存结果
item_heat.to_csv('item_heat.csv', index=False)

print(f"已生成 {len(item_heat)} 个商品的热度数据，保存至 item_heat.csv")
print(item_heat.head())