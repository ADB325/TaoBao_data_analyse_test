import pandas as pd

# 1. 读取数据，只取必要列
df = pd.read_csv('Useful_data.csv', usecols=['user_id', 'time'])

# 2. 提取日期（字符串前10位或转为datetime后取date）
df['date'] = pd.to_datetime(df['time']).dt.date

# 3. 按用户聚合：总行为次数和活跃天数
user_stats = df.groupby('user_id').agg(
    total_actions=('user_id', 'count'),        # 总行为次数
    active_days=('date', 'nunique')            # 不同日期数
).reset_index()

# 4. 计算日均行为次数
user_stats['avg_actions_per_day'] = user_stats['total_actions'] / user_stats['active_days']

# 5. 保存结果
user_stats[['user_id', 'total_actions', 'avg_actions_per_day']].to_csv(
    'user_action_stats.csv', index=False
)
print(f"已保存 {len(user_stats)} 个用户的统计信息：")
print(user_stats.head())