import pandas as pd

# 1. 读取数据
df = pd.read_csv('Useful_data.csv', usecols=['user_id', 'item_category'])

# 2. 统计每个用户在每个商品种类的交互次数
user_cat = df.groupby(['user_id', 'item_category']).size().reset_index(name='interactions')

# 3. 筛选交互次数 ≥5 的记录
interest = user_cat[user_cat['interactions'] >= 5].copy()

# 4. 统计每个商品种类下满足条件的独立用户数
cat_user_cnt = interest.groupby('item_category')['user_id'].nunique().reset_index(name='user_count')

# 5. 合并用户数
result = interest.merge(cat_user_cnt, on='item_category', how='left')

# 6. 调整列顺序并按商品种类、用户ID排序
result = result[['item_category', 'user_id', 'user_count']]
result = result.sort_values(['item_category', 'user_id']).reset_index(drop=True)

# 7. 保存
result.to_csv('user_potential_interest_category.csv', index=False)

print(f"已生成 user_potential_interest_category.csv，共 {len(result)} 条记录")
print(result.head(10))