import pandas as pd

# 1. 读取数据
df = pd.read_csv('../../../Useful_data.csv', usecols=['user_id', 'behavior_type', 'time'])

# 2. 转换时间
df['time'] = pd.to_datetime(df['time'])

# 3. 按用户+时间排序
df = df.sort_values(['user_id', 'time'])

# 4. 标记最近一次浏览/收藏(1/2)的时间
df['last_12_time'] = df['time'].where(df['behavior_type'].isin([1, 2]))
df['last_12_time'] = df.groupby('user_id')['last_12_time'].ffill()

# 5. 筛选行为3/4，计算间隔（小时）
df_34 = df[df['behavior_type'].isin([3, 4])].copy()
df_34['interval_hour'] = (df_34['time'] - df_34['last_12_time']).dt.total_seconds() / 3600

# 6. 去掉无法计算的行
df_34_valid = df_34.dropna(subset=['interval_hour'])

# 7. 按用户求平均间隔小时
user_intensity = df_34_valid.groupby('user_id')['interval_hour'].mean().reset_index()
user_intensity.columns = ['user_id', 'avg_interval_hour']

# 8. 保存
user_intensity.to_csv('user_purchase_intensity.csv', index=False)
print(f"已保存 {len(user_intensity)} 个用户的购买意愿强度（平均间隔小时）")