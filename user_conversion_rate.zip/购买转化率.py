import pandas as pd

# 读取必要列
df = pd.read_csv('Useful_data.csv', usecols=['user_id', 'behavior_type'])

# 统计每个用户的总行为次数和购买次数
agg = df.groupby('user_id')['behavior_type'].agg(
    total_actions='count',
    buy_count=lambda x: (x == 4).sum()
).reset_index()

# 直接计算转化率（无修正）
agg['conversion_rate'] = agg['buy_count'] / agg['total_actions']

# 统计转化率为1的用户（即所有行为都是购买）
pure_buyers = agg[agg['conversion_rate'] == 1]
num_pure_buyers = len(pure_buyers)

print(f"转化率为1的用户数（只有购买行为）: {num_pure_buyers}")
print(f"总用户数: {len(agg)}")

# 保存结果
agg[['user_id', 'conversion_rate']].to_csv('user_conversion_rate.csv', index=False)
print("已保存 user_conversion_rate.csv")