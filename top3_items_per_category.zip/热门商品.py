import pandas as pd

# 1. 读取数据，确认列名（打印确认）
df = pd.read_csv('Useful_data.csv', usecols=['item_category', 'item_id'])
print("列名:", df.columns.tolist())  # 应显示 ['item_category', 'item_id']

# 2. 统计每个商品的总交互次数
item_interactions = df.groupby(['item_category', 'item_id']).size().reset_index(name='interaction_count')

# 3. 对每个商品种类，取交互次数最多的前3个商品（用 pd.concat 确保保留列）
top3_list = []
for category, grp in item_interactions.groupby('item_category'):
    top3_grp = grp.nlargest(3, 'interaction_count')
    top3_list.append(top3_grp)

top3 = pd.concat(top3_list, ignore_index=True)

# 4. 调整列顺序（此时 item_category 肯定存在）
top3 = top3[['item_category', 'item_id', 'interaction_count']]

# 5. 保存
top3.to_csv('top3_items_per_category.csv', index=False)

# 6. 预览
print("已保存 top3_items_per_category.csv，前6行预览：")
print(top3.head(6))