import pandas as pd
import numpy as np

# 1. 读取数据，只取浏览行为（行为1）
df = pd.read_csv('Useful_data.csv',
                 usecols=['user_id', 'item_id', 'item_category', 'behavior_type', 'time'])
browse = df[df['behavior_type'] == 1].copy()
browse['time'] = pd.to_datetime(browse['time'])
browse = browse.sort_values(['user_id', 'item_id', 'time'])

# 2. 提取需要的列（提高效率）
browse = browse[['user_id', 'item_id', 'item_category', 'time']]


# 3. 定义分组处理函数（向量化计算）
def process_group(grp):
    # grp 是一个用户对一个商品的浏览记录，已按时间排序
    times = grp['time'].values.astype('datetime64[ns]')  # 转为 numpy 数组
    n = len(times)

    # ---- 3.1 计算每个时间点之后1小时内的浏览次数 ----
    # 对每个时间点，找第一个 时间+1小时 之后的位置
    plus1h = times + pd.Timedelta(hours=1).to_timedelta64()
    idx_1h = np.searchsorted(times, plus1h, side='right')  # 每个点窗口的右边界索引
    cnt_1h = idx_1h - np.arange(n)  # 包含当前点的窗口内个数

    # ---- 3.2 找到第一个 cnt_1h >= 3 的触发点 ----
    trigger_mask = cnt_1h >= 3
    if not trigger_mask.any():
        return None  # 该用户-商品未触发犹豫条件

    first_trigger_idx = np.argmax(trigger_mask)  # 第一次触发的位置
    trigger_time = times[first_trigger_idx]

    # ---- 3.3 统计触发之后3小时内的浏览数（不含触发点本身） ----
    start_exclusive = trigger_time + pd.Timedelta(1, 'ns').to_timedelta64()  # 严格大于触发时间
    end_inclusive = trigger_time + pd.Timedelta(hours=3).to_timedelta64()
    # 找到区间 [start_exclusive, end_inclusive] 内的记录数
    idx_start = np.searchsorted(times, start_exclusive, side='left')
    idx_end = np.searchsorted(times, end_inclusive, side='right')
    cnt_3h = idx_end - idx_start

    # 返回触发信息，包含商品种类（grp 中任意一行即可）
    cat = grp['item_category'].iloc[0]
    return pd.Series({
        'item_category': cat,
        'trigger_time': trigger_time,
        'subsequent_3h_browse_count': cnt_3h
    })


# 4. 应用分组计算，并丢弃未触发的结果
result = browse.groupby(['user_id', 'item_id']).apply(process_group, include_groups=False)
result = result.dropna().reset_index()  # 转为 DataFrame，保留 user_id, item_id

# 5. 整理输出列
result = result[['user_id', 'item_category', 'item_id', 'subsequent_3h_browse_count']]
result['subsequent_3h_browse_count'] = result['subsequent_3h_browse_count'].astype(int)

# 6. 保存
result.to_csv('user_hesitation_feature.csv', index=False)
print(f"已生成犹豫特征，共 {len(result)} 条记录，保存至 user_hesitation_feature.csv")