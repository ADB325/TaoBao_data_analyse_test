import pandas as pd

# 1. 读取数据
df = pd.read_csv('Useful_data.csv', usecols=['item_id', 'behavior_type', 'time'])
df['time'] = pd.to_datetime(df['time'])

# 2. 计算数据覆盖的总天数（按小时精确换算）
min_time = df['time'].min()
max_time = df['time'].max()
total_seconds = (max_time - min_time).total_seconds()
total_days = total_seconds / 86400   # 秒 → 天

# 3. 统计每个商品的行为2+3总次数
mask_23 = df['behavior_type'].isin([2, 3])
item_23 = df[mask_23].groupby('item_id').size().reset_index(name='count_23')

# 4. 计算平均每天次数（需求强度）
item_23['demand_intensity'] = item_23['count_23'] / total_days

# 5. 补全所有商品，无2/3行为的强度为0
all_items = pd.DataFrame({'item_id': df['item_id'].unique()})
result = all_items.merge(item_23[['item_id', 'demand_intensity']], on='item_id', how='left')
result['demand_intensity'] = result['demand_intensity'].fillna(0)

# 6. 保存
result.to_csv('item_demand_intensity.csv', index=False)

print(f"数据覆盖 {total_days:.1f} 天，已生成 {len(result)} 个商品的需求强度（平均每天收藏+加购次数）")
print(result.head())