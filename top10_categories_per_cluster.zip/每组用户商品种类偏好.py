import pandas as pd

# 1. 读取分组标签
cluster_df = pd.read_csv('user_hour_distribution_clustered.csv')
user_cluster = cluster_df[['user_id', 'cluster']].drop_duplicates()

# 2. 统计每组用户人数
group_size = user_cluster.groupby('cluster').size().reset_index(name='user_count')
print("每组用户人数：")
print(group_size)

# 3. 读取原始行为数据并合并组标签
df = pd.read_csv('Useful_data.csv', usecols=['user_id', 'item_category'])
df = df.merge(user_cluster, on='user_id', how='inner')

# 4. 统计每组-品类的行为总次数（纯计数）
group_cat = df.groupby(['cluster', 'item_category']).size().reset_index(name='action_count')

# 5. 每组取前10（确保 cluster 列保留）
top10_list = []
for cluster_id, grp in group_cat.groupby('cluster'):
    top10_grp = grp.nlargest(10, 'action_count')
    top10_list.append(top10_grp)
top10 = pd.concat(top10_list, ignore_index=True)

# 6. 合并用户人数
result = top10.merge(group_size, on='cluster', how='left')

# 7. 调整列顺序
result = result[['cluster', 'user_count', 'item_category', 'action_count']]

# 8. 保存
result.to_csv('top10_categories_per_cluster.csv', index=False)

print("\n已生成 top10_categories_per_cluster.csv")
print(result.head(20))