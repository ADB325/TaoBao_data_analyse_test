import pandas as pd

# 1. 读取数据，仅购买行为
df = pd.read_csv('Useful_data.csv', usecols=['user_id', 'item_id', 'item_category', 'behavior_type'])
purchase = df[df['behavior_type'] == 4]

# 2. 统计每个用户对每个商品的购买次数
rebuy = purchase.groupby(['user_id', 'item_id', 'item_category']).size().reset_index(name='buy_count')

# 3. 筛选购买次数 ≥ 2（即存在第二次购买）
rebuy = rebuy[rebuy['buy_count'] >= 2]

# 4. 排序并保存
rebuy = rebuy.sort_values(['user_id', 'item_id'])
rebuy.to_csv('user_rebuy_items.csv', index=False)

print(f"已生成 user_rebuy_items.csv，共 {len(rebuy)} 条记录")
print(rebuy.head(10))