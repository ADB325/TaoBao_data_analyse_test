import pandas as pd

# 1. 读取数据，只需用户ID和时间
df = pd.read_csv('Useful_data.csv', usecols=['user_id', 'time'])
df['time'] = pd.to_datetime(df['time'])

# 2. 整个数据集的统计截止日期（最新时间）
data_end = df['time'].max()

# 3. 每个用户的最后行为时间
last_action = df.groupby('user_id')['time'].max().reset_index()
last_action.columns = ['user_id', 'last_action_time']

# 4. 计算距离截止日期的天数
#    先用小时差，再转为天数（浮点数）
last_action['days_since_last'] = (data_end - last_action['last_action_time']).dt.total_seconds() / 3600 / 24

# 5. 保存（可选只保留 user_id 和 days_since_last）
last_action[['user_id', 'days_since_last']].to_csv('user_recency.csv', index=False)

print(f"已保存 {len(last_action)} 个用户的最近行为距今天数，截止日期：{data_end}")
print(last_action.head())