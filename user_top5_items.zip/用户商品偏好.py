import pandas as pd

# 1. 读取数据，只取必要列
df = pd.read_csv('Useful_data.csv', usecols=['user_id', 'item_id', 'item_category'])

# 2. 统计每个用户对每个商品的交互总次数
interactions = df.groupby(['user_id', 'item_id', 'item_category']).size().reset_index(name='interaction_count')

# 3. 每个用户取交互次数前5的商品
top5_list = []
for user_id, grp in interactions.groupby('user_id'):
    top5_grp = grp.nlargest(5, 'interaction_count')
    top5_list.append(top5_grp)

top5 = pd.concat(top5_list, ignore_index=True)

# 4. 调整列顺序（可选）
top5 = top5[['user_id', 'item_id', 'item_category', 'interaction_count']]

# 5. 保存
top5.to_csv('user_top5_items.csv', index=False)
print(f"已保存 user_top5_items.csv，共 {len(top5)} 条记录")
print(top5.head(10))