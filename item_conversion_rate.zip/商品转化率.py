import pandas as pd

# 1. 读取数据
df = pd.read_csv('Useful_data.csv', usecols=['item_id', 'behavior_type'])

# 2. 按商品聚合：总交互次数，以及转化行为（3/4）次数
item_stats = df.groupby('item_id')['behavior_type'].agg(
    total_interactions='count',
    conversions=lambda x: x.isin([3, 4]).sum()      # 加购或购买
).reset_index()

# 3. 计算转化率
item_stats['conversion_rate'] = item_stats['conversions'] / item_stats['total_interactions']

# 4. 保存（可只保留必要列）
item_stats[['item_id', 'conversion_rate']].to_csv('item_conversion_rate.csv', index=False)

print(f"已生成 {len(item_stats)} 个商品的转化率，保存至 item_conversion_rate.csv")
print(item_stats.head())