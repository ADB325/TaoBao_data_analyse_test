import pandas as pd

# 读取数据，只取必要列
df = pd.read_csv('Useful_data.csv', usecols=['item_category', 'item_id', 'user_id', 'behavior_type'])

# 分别处理收藏(2)和加购(3)
for behavior_code, behavior_name in [(2, 'fav'), (3, 'cart')]:
    # 筛选对应行为
    sub = df[df['behavior_type'] == behavior_code]

    # 统计每个商品-用户组合的行为次数
    stats = sub.groupby(['item_category', 'item_id', 'user_id']).size().reset_index(name='action_count')

    # 按商品种类、商品ID、行为次数排序（可选）
    stats = stats.sort_values(['item_category', 'item_id', 'action_count'], ascending=[True, True, False])

    # 保存为单独文件
    filename = f'item_{behavior_name}_users.csv'
    stats.to_csv(filename, index=False)
    print(f"已保存 {filename}，记录数：{len(stats)}")